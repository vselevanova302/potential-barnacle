# Flexoki for Visual Studio Code

Also available as an option in [One Hunter theme](https://github.com/Railly/one-hunter-vscode). 

### Flexoki Dark

![Flexoki dark for VS Code](/vscode/flexoki-vscode-dark.png)

### Flexoki Light

![Flexoki light for VS Code](/vscode/flexoki-vscode-light.png)