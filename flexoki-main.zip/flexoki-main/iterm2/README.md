## Flexoki Dark
![Flexoki Dark](screenshots/flexoki_dark.itermcolors.png)

## Flexoki Dark Dimmed
![Flexoki Dark](screenshots/flexoki_dark_dimmed.itermcolors.png)

## Flexoki Light
![Flexoki Light](screenshots/flexoki_light.itermcolors.png)

## Flexoki Light Dimmed
![Flexoki Light](screenshots/flexoki_light_dimmed.itermcolors.png)
