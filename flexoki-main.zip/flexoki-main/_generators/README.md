# Generators

```bash
npm i
npm run build
```