import { generateITerm2ColorSchemes } from "./iterm2"

async function main() {
    await generateITerm2ColorSchemes()
}

void main()