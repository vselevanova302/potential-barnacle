# Installation instructions

1. Open Windows Terminal

2. Press <kbd>Ctrl</kbd>+<kbd>,</kbd> or click the down arrow next to the new tab button and click "Settings"

3. Click "Open JSON File" in the bottom left

4. Find the `schemes` key and paste the contents of the JSON file in there

5. Now you should be able to select the "Flexoki" theme for your profiles or as the default from the settings UI
